package koreait.test999;
//사승철
public abstract class Product {
	
	protected int price;
	
	protected String prdName;
	
	public abstract String sell(Object obj);
	

}
